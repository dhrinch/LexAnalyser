#include "clex.h"
#include <fstream>

string code2String(char* fileName);

int CLex::getNearestDelimiterPos(string s, string& delimiter)
{
    int nearestPos = -1;
    delimiter = "";
    for(int i = 0; i<delimiters.size(); i++)
    {
        int pos = s.find(delimiters[i]);
        if (pos>=0)
        {
            if(nearestPos == -1)
            {
                nearestPos = pos;
                delimiter = delimiters[i];
            }
            else
            {
                if(pos<nearestPos)
                {
                    nearestPos = pos;
                    delimiter = delimiters[i];
                }
            }
        }
    }
    return nearestPos;
}

void CLex::parse(string s)
{
    lexemes.clear();
    while(s.size()>0)
    {
        string delimiter;
        int pos = getNearestDelimiterPos(s, delimiter);
        if(pos>0)
        {
            string lex = s.substr(0, pos);
            lexemes.push_back(lex);
            s.erase(0, pos);
        }
        if(pos == 0)
        {
            if(delimiter != " ")
            {
                lexemes.push_back(delimiter);
            }
            s.erase(0, delimiter.size());
        }
    }
}

const string CLex::operator[](int lexIdx) const
{
    if(lexIdx<0) return "";
    if(lexIdx>=lexemes.size())return "";
    return lexemes[lexIdx];
}

string CLex::operator[](int lexIdx)
{
    if(lexIdx<0) return "";
    if(lexIdx>=lexemes.size())return "";
    return lexemes[lexIdx];
}

CLex::CLex(char* fileName)
{
    string s = code2String(fileName);
    cout<<s<<endl;
    delimiters.push_back("==");
    delimiters.push_back("!=");
    delimiters.push_back("<=");
    delimiters.push_back(">=");
    delimiters.push_back("++");
    delimiters.push_back("--");
    delimiters.push_back("+=");
    delimiters.push_back("-=");
    delimiters.push_back("*=");
    delimiters.push_back("/=");
    delimiters.push_back("{");
    delimiters.push_back("}");
    delimiters.push_back("(");
    delimiters.push_back(")");
    delimiters.push_back("=");
    delimiters.push_back("+");
    delimiters.push_back("-");
    delimiters.push_back("*");
    delimiters.push_back("/");
    delimiters.push_back(">");
    delimiters.push_back("<");
    delimiters.push_back(";");
    delimiters.push_back(",");
    delimiters.push_back(" ");
    parse(s);
}

CLex::~CLex()
{
    //dtor
}

string code2String(char* fileName)
{
    string result;
    ifstream in(fileName);
    if(in.is_open())
    {
        string s;
        //while(in>>s)
        while(getline(in, s))
        {
            result+=s;
        }
    }
    else cout<<"File not found";
    for (int i = 0; i<result.size(); i++)
    {
        if(result[i]<32) result[i] = 32;
    }
    return result;
}




