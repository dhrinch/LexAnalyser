#ifndef CLEX_H
#define CLEX_H
#include <string>
#include <iostream>
#include <vector>

using namespace std;

class CLex
{
    vector<string> delimiters;
    vector<string> lexemes;
    int getNearestDelimiterPos(string s, string& delimiter);
    void parse(string s);
public:
    CLex(char* fileName);
    virtual ~CLex();
    int getLexCount() const {return lexemes.size();}
    const string operator[](int lexIdx) const;
    string operator[](int lexIdx);
    int getSize() const {return lexemes.size();}
};

#endif // CLEX_H
