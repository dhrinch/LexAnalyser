int x;
int y;
y=x+5;
x=0;
for(int i = 0; i<10;i++)
{
	x = x + y;
}